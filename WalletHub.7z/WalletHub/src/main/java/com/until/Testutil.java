package com.until;

public class Testutil {
	
	public static long PAGE_LOAD_TIME = 10;
	public static  long IMPLICIT_WAIT =10;

}
