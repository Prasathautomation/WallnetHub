package com.testcases.FB;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.base.testbase;
import com.pagesource.Facebook_Home_Screen;
import com.pagesource.Facebook_Login_Screen;

public class FB_Login_Test extends testbase {

	public Facebook_Login_Screen login;
	public Facebook_Home_Screen home;

	public FB_Login_Test() {
		super();
	}

	@BeforeMethod

	public void setup() {

		initialization();
		login = new Facebook_Login_Screen();
		home = new Facebook_Home_Screen();
	}

	@Test

	public void userlogin() {

		login.userrolelogin("noramluser");
	}

	@Test
	public void createpost() {

		home.createpost();
	}

	// @AfterMethod

	// public void tearDown() throws InterruptedException {
	//
	// Thread.sleep(12000);
	//
	// driver.quit();
	// }

}
