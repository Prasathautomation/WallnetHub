package com.pagesource;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.testbase;
import com.config.Credentials;

public class Facebook_Login_Screen extends testbase {

	Credentials user = new Credentials();

	// page factory Or Object repository:

	@FindBy(id = "email")
	WebElement Emailaddress_fld;
	@FindBy(id = "pass")
	WebElement Password_fld;
	@FindBy(xpath = "//button[@name='login']")
	WebElement login_btn;

	// initializing the Page Object:

	public Facebook_Login_Screen() {

		PageFactory.initElements(driver, this);
	}

	// Actions:

	public void userrolelogin(String roles) {

		Emailaddress_fld.sendKeys(Credentials.GetUsername(roles));
		Password_fld.sendKeys(Credentials.GetPassword(roles));
		login_btn.click();
	}

}
