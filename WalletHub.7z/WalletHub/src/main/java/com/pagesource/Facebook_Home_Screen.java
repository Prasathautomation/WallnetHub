package com.pagesource;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.testbase;

public class Facebook_Home_Screen extends testbase {

	// page factory Or Object repository:

	@FindBy(xpath = "//div[contains(@class,'m9osqain a5q79mjw')]//span[1]")
	WebElement createPost;
	
	
	
	@FindBy(xpath = "(//div[@class='taijpn5t j83agx80']//div)[1]")
	WebElement writetextbox;
	@FindBy(xpath = "//span[text()='Post']")
	WebElement post_btn;

	// initializing the Page Object:

	public Facebook_Home_Screen() {

		PageFactory.initElements(driver, this);
	}

	// Actions:

	public void createpost() {

		createPost.click();
		writetextbox.sendKeys("Hello World");
		boolean displayed = post_btn.isDisplayed();
		if (displayed == true) {
			//post_btn.click();	
			System.out.println("The post is created ");
		}

	}

}
