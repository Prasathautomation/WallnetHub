package com.config;

import java.util.HashMap;

public class Credentials {

	public static void main(String[] args) {

		System.out.println(GetUsername("noramluser"));
		System.out.println(GetPassword("noramluser"));

	}

	public static HashMap<String, String> RolesofUserLogin() {

		HashMap<String, String> Roles = new HashMap<String, String>();
		Roles.put("noramluser", "larafedrick95@gmail.com:Larafedrick1104");
		return Roles;
	}

	public static String GetUsername(String roles) {

		String Username = RolesofUserLogin().get(roles);
		return Username.split(":")[0];
	}

	public static String GetPassword(String roles) {

		String Password = RolesofUserLogin().get(roles);
		return Password.split(":")[1];
	}

}
